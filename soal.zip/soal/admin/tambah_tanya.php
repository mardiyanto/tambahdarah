<?php
session_start();
	if($_POST["pasien"]){
			include_once("../library/koneksi.php");
			
	$no 	 = $_POST['no'];
	$soal	 = $_POST['soal'];
	$a	= $_POST['a'];
	$b  = $_POST['b'];
	$c	= $_POST['c'];
	$d	= $_POST['d'];
	$kunci	= $_POST['kunci'];
	
	 $sql="INSERT INTO tanya SET 
	no='$no', 
	soal='$soal',
	a='$a', 
	b='$b',
	c='$c', 
	d='$d', 
	kunci='$kunci'";
	$query = mysql_query($sql);
			echo("<script>
		swal('Good Job!', 'Data anda sukses tersimpan', 'success');

		</script>");
			echo "<center><div class='alert alert-success alert-dismissable'>
                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
					<b>Berhasil menambah ke database!!</b>
			</div>
			
			<center>
			
			";
			
	}else if(isset($_POST["pasien"])){
		echo "<center><div class='alert alert-warning alert-dismissable'>
                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
					<b>Gagal menambah ke database!!</b>
			</div><center>";
	}
?>
<div class="box">

	<header>
		<h5>Form Tambah Pertanyaan</h5>
	</header>
		<div class="body">
			<form action="" method="post" class="form-horizontal">
			<div class="form-group">
							<label class="control-label col-lg-4">Soal</label>
							<div class="col-lg-4">
								<input type="text" name="soal" autofocus required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_A</label>
							<div class="col-lg-4">
								<input type="text" name="a" autofocus required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_B</label>
							<div class="col-lg-4">
								<input type="text" name="b" autofocus required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_C</label>
							<div class="col-lg-4">
								<input type="text" name="c" autofocus required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_D</label>
							<div class="col-lg-4">
								<input type="text" name="d" autofocus required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Kunci Jwbn</label>
							<div class="col-lg-4">
								<input type="text" name="kunci" autofocus required class="form-control" />
							</div>
						</div>
						
						<div class="form-actions no-margin-bottom" style="text-align:center;">
							<input type="submit" name="pasien" value="Simpan" class="btn btn-primary" /> <a href="?menu=tanya" class="btn btn-warning">Back</a>
						</div>

					</form>
	</div>
</div>