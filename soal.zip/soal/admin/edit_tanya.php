<?php
if($_GET["aksi"] && $_GET["nmr"]){
include_once("../library/koneksi.php");
$edit = mysql_query("select * from tanya where no='".$_GET["nmr"]."'");
$editDb = mysql_fetch_assoc($edit);
	if($_POST["pasien"]){
			include_once("../library/koneksi.php");
			mysql_query("update tanya set soal='".$_POST["soal"]."',
			a='".$_POST["a"]."', 
			b='".$_POST["b"]."', 
			c='".$_POST["c"]."', 
			d='".$_POST["d"]."', 
			kunci='".$_POST["kunci"]."' where no='".$_GET["nmr"]."'");
			echo "<meta http-equiv='refresh' content='0; url=?menu=tanya'>";
			
	}
?>
<div class="span9">
	<div class="well" style="fixed:center;">
		<b>Edit Pertanyaan</b>
		<p style="margin-top:10px;">
			<form action="" method="post" class="form-horizontal">
			<div class="form-group">
							<label class="control-label col-lg-4">Soal</label>
							<div class="col-lg-4">
								<input type="text" name="soal" value="<?php echo $editDb["soal"];?>" required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_A</label>
							<div class="col-lg-4">
								<input type="text" name="a" value="<?php echo $editDb["a"];?>" required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_B</label>
							<div class="col-lg-4">
								<input type="text" name="b" value="<?php echo $editDb["b"];?>" required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_C</label>
							<div class="col-lg-4">
								<input type="text" name="c" value="<?php echo $editDb["c"];?>" required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Pilihan_D</label>
							<div class="col-lg-4">
								<input type="text" name="d" value="<?php echo $editDb["d"];?>" required class="form-control" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-4">Kunci</label>
							<div class="col-lg-4">
								<input type="text" name="kunci" value="<?php echo $editDb["kunci"];?>" required class="form-control" />
							</div>
						</div>
						
						
						
						<div class="form-actions no-margin-bottom" style="text-align:center;">
							<input type="submit" name="pasien" value="Simpan" class="btn btn-primary" /> <a href="?menu=tanya" class="btn btn-warning">Batal</a>
						</div>

					</form>
	</div>
</div>
<?php } ?>