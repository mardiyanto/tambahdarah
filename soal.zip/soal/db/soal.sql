-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 03 Mei 2018 pada 16.38
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `soal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `kd_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `alamat` text NOT NULL,
  PRIMARY KEY (`kd_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`kd_user`, `username`, `password`, `nama`, `alamat`) VALUES
(11, 'admin', 'admin', 'administrator', 'jl.berok raya no 40 siteba');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tanya`
--

CREATE TABLE IF NOT EXISTS `tanya` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `soal` text NOT NULL,
  `a` varchar(1000) NOT NULL,
  `b` varchar(1000) NOT NULL,
  `c` varchar(1000) NOT NULL,
  `d` varchar(1000) NOT NULL,
  `kunci` varchar(1000) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `tanya`
--

INSERT INTO `tanya` (`no`, `soal`, `a`, `b`, `c`, `d`, `kunci`) VALUES
(1, 'Siapa presiden pertama Indonesia', 'Soekarno', 'Suharto', 'Ki Hajar Dewantara', 'Megawati Soekarno Puteri', 'Soekarno'),
(2, 'Apa kepanjangan dari NKRI', 'Negara Kesatuan Rakyat Indonesia', 'Negara Kesatuan Republik Indonesia', 'Negara Kedaulatan Republik Indonesia', 'Negara Kekeluargaan Rakyat Indonesia', 'Negara Kesatuan Republik Indonesia'),
(3, '2 + 2 = ', '10:3', '8:4', '(2:2)x(2*2)', '7:3', '(2:2)x(2*2)'),
(4, 'UPI merupakan singkatan dari', 'Universitas Padahal IKIP', 'Universitas Pendidikan Indonesia', 'Universitas Pelawak Internasional', 'Semua Benar', 'Universitas Pendidikan Indonesia'),
(5, 'Makanan khas cirebon', 'gado-gado', 'godeg', 'nasi jamblang', 'rendang', 'nasi jamblang'),
(6, 'Malaikat pengantar wahyu', 'zibril', 'Nakir', 'Mikail', 'Isrofil', 'zibril'),
(8, '5+2', '0', '9', '7', '9', '7'),
(9, 'hewan lokturnal', 'burung hantu', 'cacing ', 'kucing', 'ayam', 'burung hantu'),
(10, 'Grup Band asal cirebon', 'ST 12', 'Slank', 'Gigi', 'Dua Ratu', 'ST 12'),
(11, 'Kota yang di Juluki Kota Pahlawan', 'Cirebon', 'Banten', 'Surabaya', 'Pati', 'Surabaya');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
